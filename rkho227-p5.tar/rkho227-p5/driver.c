#include "procsig.h"
/* parent:
 * 0. parse arg to get nprocs
 * 1. Open/Create SYNCFILE for reading/writing.
 * 2. fork off nproc children in a loop, passing info to eacc via doChild()
 * 3. print childrens' PIDs in order they should speak, for verification
 * 3. wait for child procs (overlay) to say they're ready (SYNCFILE)
 * 4. print contents of SYNCFILE to verify all have reported
 * 5. arrange to ignore SIGUSR1
 * 6. send SIGUSR1 to all children (via pgrp) as start signal
 * 7. Reap children and say whether they terminated normally.
 */

void doChild(int ord, int nprocs, pid_t prevpid);

int main(int argc, char *argv[]) {
  int i,j,fd;
  pid_t cpid;
  pid_t children[MAXPROC];
  struct stat statbuf;
  char inbuf[MAXPROC+1];
  int wstatus;
  
  if (argc < 2)
    DieWithError("argc");
  int nprocs = atoi(argv[1]);
  if (nprocs < MINPROC || nprocs > MAXPROC)
    DieWithError("number of procs out of range");

  /* open the file for the kids to write into when ready. */
  /* this will persist across execve() */
  /*******************************************************/
  /* YOUR CODE HERE                                      */
  /* Hint: man 2 open                                    */
  /* Hint: Filename is #defined as SYNCFILE              */
  /* Hint: check return values!                          */
  /*******************************************************/
  if ((fd = open(SYNCFILE, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH |  S_IWOTH)) < 0) 
  {
	  perror("open");
	  exit(1);
  }

  /* create nprocs children */
  for (i=0; i<nprocs; i++) {
    cpid = fork();
    if (cpid < 0)
      DieWithError("fork()");
    else if (cpid == 0) { /* child */
      doChild(i,nprocs,(i>0 ? children[i-1] : 0)); /* does not return */
      /* NOTREACHED */
    } else /* parent */
      children[i] = cpid;
  }
  
  /* parent: print the kids' PIDs in the order they should speak */
  for (i=0, j=nprocs-1; i<nprocs; i++, j--)
    printf("Parent: %d is PID=%d \n",i+1,children[j]);

  /* wait for the file size to == nprocs, => all kids are ready */

  /**************************************************************/
  /* YOUR CODE HERE                                             */
  /* Hint: fstat() in a do-while loop                           */
  /**************************************************************/
  do
  {
	  fstat(fd, &statbuf);
  }

  while (statbuf.st_size != nprocs);

  /* Now read the contents of the file and print, to verify     */
  
  /**************************************************************/
  /* YOUR CODE HERE                                             */
  /* You MUST use lseek() and read().                           */
  /* HINT: read() does not know about strings!                  */
  /* If you use printf() make sure strings are null-terminated. */
  /*************************************************************/
  
  lseek(fd, 0, SEEK_SET);
  if ((read(fd, inbuf, nprocs)) < 0 ) 
  {
	  perror("read");
	  exit(1);
  }
 
	  inbuf[nprocs] = '\0';
	  printf("Children Reported: %s\n", inbuf);
 
  /* we're done with the file; remove it.                       */
  unlink(SYNCFILE);

  /* we must ignore SIGUSR1 b/c we will receive it also */
  Signal(SIGUSR1,SIG_IGN);
  
  /* send SIGUSR1 to all processes in our process group (including us)  */

  /**************************************************************/
  /* YOUR CODE HERE                                             */
  /* Hint: man 2 kill                                           */
  /**************************************************************/

  kill(0, SIGUSR1);
   
  /* the rest is up to the kids - reap them as they terminate   */
  /* For each child, print a line of the form:                  */
  /* "Process <pid> terminated normally with status <status>"   */
  /* or, in case it didn't,                                     */
  /* "Process <pid> terminated abnormally."                     */
  
  for (i=0; i<nprocs; i++) {
	  cpid = wait(&wstatus);
	  if (WIFEXITED(wstatus))
		  printf("Process %d terminated normally with status %d\n", cpid, WEXITSTATUS(wstatus));
	  else
		  printf("Process %d terminated abnormally\n", cpid);
    /**************************************************************/
    /* YOUR CODE HERE                                             */
    /* Hint:  wait(), WIFEXITED(), WEXITSTATUS()                  */
    /**************************************************************/
  }
  return 0;
}
