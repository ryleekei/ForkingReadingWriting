#include "procsig.h"
/* doChild:
 * 0. set up args:
 *      args[0] = OVRLYPROG
 *      args[1] = my ordinal (a single digit in [1,nprocs])
 *      args[2] = nprocs (a single digit in [MINPROC-MAXPROC])
 * 1. set up environment:
 *      envstrs[0] = "NEXTPID=<successor pid>"
 * 2. execve("./OVRLYPROG",args,envstrs);
 * Bails on failure at any point.
 */

void doChild(int ord, int nprocs, pid_t succpid) {
  int myord; /* My place in the printing order */
  char progname[MAXSTRING];
  char ordarg[2];
  char nparg[2];
  char envbuf[MAXSTRING];
  char *args[NARGS];
  char *envars[NENV];

  myord = nprocs - ord;

  /* set up argument array                             */
  sprintf(args[0], "%s", OVRLYPROG);
  
  sprintf(ordarg, "%d", myord);
  args[1] = ordarg;

  sprintf(nparg, "%d", nprocs);
  args[2] = nparg;
  args[3] = NULL;

  /*****************************************************/
  /* YOUR CODE HERE                                    */
  /* Hint: strngs must be null-terminated              */
  /* Hint: args list is terminated by a NULL pointer   */
  /*****************************************************/

  /* set up array of environment strings               */
 sprintf(envbuf, "NEXTPID=%d", succpid);
 envars[0] = envbuf;
 envars[1] = NULL;
  /*****************************************************/
  /* YOUR CODE HERE                                    */
  /* MUST include a string of the form "NEXTPID=<pid>" */
  /* Hint: strngs must be null-terminated              */
  /* Hint: env list is terminated by a NULL pointer    */
  /*****************************************************/

  /* put name of program to execute in progname        */
  sprintf(progname, "./%s", OVRLYPROG); 
  
  if(execve(progname,args,envars) < 0)
	  DieWithError("execve");
  /* HINT: must start with "./" or "/"                 */
  /*****************************************************/
	
  /* replace this program with the executable OVRLYPROG  */
  /*******************************************************/
  /* YOUR CODE HERE                                      */
  /* HINT: execve()                                      */
  /* HINT: CHECK RETURN VALUE!                           */
  /*******************************************************/

} /* doChild */
